﻿namespace c34104032_practice_3_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.statusLabel1 = new System.Windows.Forms.Label();
            this.stackLabel1 = new System.Windows.Forms.Label();
            this.stackLabel4 = new System.Windows.Forms.Label();
            this.stackLabel3 = new System.Windows.Forms.Label();
            this.stackLabel2 = new System.Windows.Forms.Label();
            this.startButton = new System.Windows.Forms.Button();
            this.stackBox1 = new System.Windows.Forms.TextBox();
            this.stackBox3 = new System.Windows.Forms.TextBox();
            this.stackBox4 = new System.Windows.Forms.TextBox();
            this.stackBox2 = new System.Windows.Forms.TextBox();
            this.statusLabel2 = new System.Windows.Forms.Label();
            this.homeButton = new System.Windows.Forms.Button();
            this.stackCol1 = new System.Windows.Forms.Label();
            this.stackCol2 = new System.Windows.Forms.Label();
            this.stackCol3 = new System.Windows.Forms.Label();
            this.stackCol4 = new System.Windows.Forms.Label();
            this.selectButton1 = new System.Windows.Forms.Button();
            this.selectButton4 = new System.Windows.Forms.Button();
            this.selectButton3 = new System.Windows.Forms.Button();
            this.selectButton2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // statusLabel1
            // 
            this.statusLabel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.statusLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.statusLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.statusLabel1.Location = new System.Drawing.Point(26, 29);
            this.statusLabel1.Name = "statusLabel1";
            this.statusLabel1.Size = new System.Drawing.Size(381, 44);
            this.statusLabel1.TabIndex = 0;
            this.statusLabel1.Text = "請輸入測資";
            // 
            // stackLabel1
            // 
            this.stackLabel1.AutoSize = true;
            this.stackLabel1.Location = new System.Drawing.Point(23, 100);
            this.stackLabel1.Name = "stackLabel1";
            this.stackLabel1.Size = new System.Drawing.Size(44, 15);
            this.stackLabel1.TabIndex = 1;
            this.stackLabel1.Text = "堆疊1";
            // 
            // stackLabel4
            // 
            this.stackLabel4.AutoSize = true;
            this.stackLabel4.Location = new System.Drawing.Point(23, 250);
            this.stackLabel4.Name = "stackLabel4";
            this.stackLabel4.Size = new System.Drawing.Size(44, 15);
            this.stackLabel4.TabIndex = 2;
            this.stackLabel4.Text = "堆疊4";
            // 
            // stackLabel3
            // 
            this.stackLabel3.AutoSize = true;
            this.stackLabel3.Location = new System.Drawing.Point(23, 200);
            this.stackLabel3.Name = "stackLabel3";
            this.stackLabel3.Size = new System.Drawing.Size(44, 15);
            this.stackLabel3.TabIndex = 3;
            this.stackLabel3.Text = "堆疊3";
            // 
            // stackLabel2
            // 
            this.stackLabel2.AutoSize = true;
            this.stackLabel2.Location = new System.Drawing.Point(23, 150);
            this.stackLabel2.Name = "stackLabel2";
            this.stackLabel2.Size = new System.Drawing.Size(44, 15);
            this.stackLabel2.TabIndex = 4;
            this.stackLabel2.Text = "堆疊2";
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.SystemColors.Window;
            this.startButton.Location = new System.Drawing.Point(143, 305);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(155, 42);
            this.startButton.TabIndex = 5;
            this.startButton.Text = "開始遊戲";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stackBox1
            // 
            this.stackBox1.Location = new System.Drawing.Point(73, 97);
            this.stackBox1.Name = "stackBox1";
            this.stackBox1.Size = new System.Drawing.Size(334, 25);
            this.stackBox1.TabIndex = 6;
            // 
            // stackBox3
            // 
            this.stackBox3.Location = new System.Drawing.Point(73, 197);
            this.stackBox3.Name = "stackBox3";
            this.stackBox3.Size = new System.Drawing.Size(334, 25);
            this.stackBox3.TabIndex = 7;
            // 
            // stackBox4
            // 
            this.stackBox4.Location = new System.Drawing.Point(73, 247);
            this.stackBox4.Name = "stackBox4";
            this.stackBox4.Size = new System.Drawing.Size(334, 25);
            this.stackBox4.TabIndex = 8;
            // 
            // stackBox2
            // 
            this.stackBox2.Location = new System.Drawing.Point(73, 147);
            this.stackBox2.Name = "stackBox2";
            this.stackBox2.Size = new System.Drawing.Size(334, 25);
            this.stackBox2.TabIndex = 9;
            // 
            // statusLabel2
            // 
            this.statusLabel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.statusLabel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.statusLabel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.statusLabel2.Location = new System.Drawing.Point(26, 396);
            this.statusLabel2.Name = "statusLabel2";
            this.statusLabel2.Size = new System.Drawing.Size(192, 57);
            this.statusLabel2.TabIndex = 10;
            this.statusLabel2.Text = "...";
            // 
            // homeButton
            // 
            this.homeButton.BackColor = System.Drawing.SystemColors.Window;
            this.homeButton.Location = new System.Drawing.Point(244, 411);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(163, 42);
            this.homeButton.TabIndex = 11;
            this.homeButton.Text = "回主畫面";
            this.homeButton.UseVisualStyleBackColor = false;
            this.homeButton.Click += new System.EventHandler(this.homeButton_Click);
            // 
            // stackCol1
            // 
            this.stackCol1.BackColor = System.Drawing.SystemColors.Window;
            this.stackCol1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.stackCol1.Location = new System.Drawing.Point(26, 62);
            this.stackCol1.Name = "stackCol1";
            this.stackCol1.Size = new System.Drawing.Size(73, 285);
            this.stackCol1.TabIndex = 12;
            this.stackCol1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // stackCol2
            // 
            this.stackCol2.BackColor = System.Drawing.SystemColors.Window;
            this.stackCol2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.stackCol2.Location = new System.Drawing.Point(125, 62);
            this.stackCol2.Name = "stackCol2";
            this.stackCol2.Size = new System.Drawing.Size(73, 285);
            this.stackCol2.TabIndex = 13;
            this.stackCol2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // stackCol3
            // 
            this.stackCol3.BackColor = System.Drawing.SystemColors.Window;
            this.stackCol3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.stackCol3.Location = new System.Drawing.Point(225, 62);
            this.stackCol3.Name = "stackCol3";
            this.stackCol3.Size = new System.Drawing.Size(73, 285);
            this.stackCol3.TabIndex = 14;
            this.stackCol3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // stackCol4
            // 
            this.stackCol4.BackColor = System.Drawing.SystemColors.Window;
            this.stackCol4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.stackCol4.Location = new System.Drawing.Point(334, 62);
            this.stackCol4.Name = "stackCol4";
            this.stackCol4.Size = new System.Drawing.Size(73, 285);
            this.stackCol4.TabIndex = 15;
            this.stackCol4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // selectButton1
            // 
            this.selectButton1.BackColor = System.Drawing.SystemColors.Window;
            this.selectButton1.Location = new System.Drawing.Point(24, 359);
            this.selectButton1.Name = "selectButton1";
            this.selectButton1.Size = new System.Drawing.Size(75, 34);
            this.selectButton1.TabIndex = 16;
            this.selectButton1.Text = "選取";
            this.selectButton1.UseVisualStyleBackColor = false;
            this.selectButton1.Click += new System.EventHandler(this.selectButton1_Click);
            // 
            // selectButton4
            // 
            this.selectButton4.BackColor = System.Drawing.SystemColors.Window;
            this.selectButton4.Location = new System.Drawing.Point(332, 359);
            this.selectButton4.Name = "selectButton4";
            this.selectButton4.Size = new System.Drawing.Size(75, 34);
            this.selectButton4.TabIndex = 17;
            this.selectButton4.Text = "選取";
            this.selectButton4.UseVisualStyleBackColor = false;
            this.selectButton4.Click += new System.EventHandler(this.selectButton4_Click);
            // 
            // selectButton3
            // 
            this.selectButton3.BackColor = System.Drawing.SystemColors.Window;
            this.selectButton3.Location = new System.Drawing.Point(225, 359);
            this.selectButton3.Name = "selectButton3";
            this.selectButton3.Size = new System.Drawing.Size(75, 34);
            this.selectButton3.TabIndex = 18;
            this.selectButton3.Text = "選取";
            this.selectButton3.UseVisualStyleBackColor = false;
            this.selectButton3.Click += new System.EventHandler(this.selectButton3_Click);
            // 
            // selectButton2
            // 
            this.selectButton2.BackColor = System.Drawing.SystemColors.Window;
            this.selectButton2.Location = new System.Drawing.Point(125, 359);
            this.selectButton2.Name = "selectButton2";
            this.selectButton2.Size = new System.Drawing.Size(75, 34);
            this.selectButton2.TabIndex = 19;
            this.selectButton2.Text = "選取";
            this.selectButton2.UseVisualStyleBackColor = false;
            this.selectButton2.Click += new System.EventHandler(this.selectButton2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(432, 503);
            this.Controls.Add(this.selectButton2);
            this.Controls.Add(this.selectButton3);
            this.Controls.Add(this.selectButton4);
            this.Controls.Add(this.selectButton1);
            this.Controls.Add(this.homeButton);
            this.Controls.Add(this.statusLabel2);
            this.Controls.Add(this.stackBox2);
            this.Controls.Add(this.stackBox4);
            this.Controls.Add(this.stackBox3);
            this.Controls.Add(this.stackBox1);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.stackLabel2);
            this.Controls.Add(this.stackLabel3);
            this.Controls.Add(this.stackLabel4);
            this.Controls.Add(this.stackLabel1);
            this.Controls.Add(this.statusLabel1);
            this.Controls.Add(this.stackCol1);
            this.Controls.Add(this.stackCol2);
            this.Controls.Add(this.stackCol3);
            this.Controls.Add(this.stackCol4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label statusLabel1;
        private System.Windows.Forms.Label stackLabel1;
        private System.Windows.Forms.Label stackLabel4;
        private System.Windows.Forms.Label stackLabel3;
        private System.Windows.Forms.Label stackLabel2;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.TextBox stackBox1;
        private System.Windows.Forms.TextBox stackBox3;
        private System.Windows.Forms.TextBox stackBox4;
        private System.Windows.Forms.TextBox stackBox2;
        private System.Windows.Forms.Label statusLabel2;
        private System.Windows.Forms.Button homeButton;
        private System.Windows.Forms.Label stackCol1;
        private System.Windows.Forms.Label stackCol2;
        private System.Windows.Forms.Label stackCol3;
        private System.Windows.Forms.Label stackCol4;
        private System.Windows.Forms.Button selectButton1;
        private System.Windows.Forms.Button selectButton4;
        private System.Windows.Forms.Button selectButton3;
        private System.Windows.Forms.Button selectButton2;
    }
}

