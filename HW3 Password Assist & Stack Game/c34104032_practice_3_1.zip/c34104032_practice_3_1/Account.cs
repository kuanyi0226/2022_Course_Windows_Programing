﻿using System;

namespace Account
{
    class Account
    {
        public string link, user, password;


        public Account(string _link, string _user, string _password)
        {
            link = _link;
            user = _user;
            password = _password;
        }
    }
}


