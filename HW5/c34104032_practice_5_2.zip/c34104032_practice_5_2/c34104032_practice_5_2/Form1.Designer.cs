﻿namespace c34104032_practice_5_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.startButton = new System.Windows.Forms.Button();
            this.turnLabel = new System.Windows.Forms.Label();
            this.p1Label = new System.Windows.Forms.Label();
            this.p2Label = new System.Windows.Forms.Label();
            this.p1Atk = new System.Windows.Forms.Button();
            this.p1Move = new System.Windows.Forms.Button();
            this.p1Skill = new System.Windows.Forms.Button();
            this.p1Skip = new System.Windows.Forms.Button();
            this.p1Over = new System.Windows.Forms.Button();
            this.p2Over = new System.Windows.Forms.Button();
            this.p2Skip = new System.Windows.Forms.Button();
            this.p2Skill = new System.Windows.Forms.Button();
            this.p2Move = new System.Windows.Forms.Button();
            this.p2Atk = new System.Windows.Forms.Button();
            this.p1ChooseWiz = new System.Windows.Forms.Button();
            this.p1ChooseRan = new System.Windows.Forms.Button();
            this.p2ChooseRan = new System.Windows.Forms.Button();
            this.p2ChooseWiz = new System.Windows.Forms.Button();
            this.p2ChooseWar = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.p1ChooseWar = new System.Windows.Forms.Button();
            this.p1CharLabel = new System.Windows.Forms.Label();
            this.p2CharLabel = new System.Windows.Forms.Label();
            this.p1InfoLabel = new System.Windows.Forms.Label();
            this.p2InfoLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Window;
            this.button1.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(250, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Window;
            this.button2.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(300, 100);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Window;
            this.button3.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(350, 100);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 50);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(351, 206);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(99, 71);
            this.startButton.TabIndex = 43;
            this.startButton.Text = "開始遊戲";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // turnLabel
            // 
            this.turnLabel.AutoSize = true;
            this.turnLabel.Font = new System.Drawing.Font("新細明體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.turnLabel.Location = new System.Drawing.Point(326, 9);
            this.turnLabel.Name = "turnLabel";
            this.turnLabel.Size = new System.Drawing.Size(147, 33);
            this.turnLabel.TabIndex = 44;
            this.turnLabel.Text = "準備階段";
            this.turnLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.turnLabel.Visible = false;
            // 
            // p1Label
            // 
            this.p1Label.AutoSize = true;
            this.p1Label.Font = new System.Drawing.Font("新細明體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.p1Label.Location = new System.Drawing.Point(103, 68);
            this.p1Label.Name = "p1Label";
            this.p1Label.Size = new System.Drawing.Size(48, 33);
            this.p1Label.TabIndex = 45;
            this.p1Label.Text = "P1";
            this.p1Label.Visible = false;
            // 
            // p2Label
            // 
            this.p2Label.AutoSize = true;
            this.p2Label.Font = new System.Drawing.Font("新細明體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.p2Label.Location = new System.Drawing.Point(648, 68);
            this.p2Label.Name = "p2Label";
            this.p2Label.Size = new System.Drawing.Size(48, 33);
            this.p2Label.TabIndex = 46;
            this.p2Label.Text = "P2";
            this.p2Label.Visible = false;
            // 
            // p1Atk
            // 
            this.p1Atk.BackColor = System.Drawing.SystemColors.Window;
            this.p1Atk.Location = new System.Drawing.Point(44, 269);
            this.p1Atk.Name = "p1Atk";
            this.p1Atk.Size = new System.Drawing.Size(72, 42);
            this.p1Atk.TabIndex = 47;
            this.p1Atk.Tag = "p1";
            this.p1Atk.Text = "攻擊";
            this.p1Atk.UseVisualStyleBackColor = false;
            this.p1Atk.Visible = false;
            this.p1Atk.Click += new System.EventHandler(this.p1Atk_Click);
            // 
            // p1Move
            // 
            this.p1Move.BackColor = System.Drawing.SystemColors.Window;
            this.p1Move.Location = new System.Drawing.Point(135, 269);
            this.p1Move.Name = "p1Move";
            this.p1Move.Size = new System.Drawing.Size(72, 42);
            this.p1Move.TabIndex = 48;
            this.p1Move.Tag = "p1";
            this.p1Move.Text = "移動";
            this.p1Move.UseVisualStyleBackColor = false;
            this.p1Move.Visible = false;
            // 
            // p1Skill
            // 
            this.p1Skill.BackColor = System.Drawing.SystemColors.Window;
            this.p1Skill.Location = new System.Drawing.Point(44, 326);
            this.p1Skill.Name = "p1Skill";
            this.p1Skill.Size = new System.Drawing.Size(72, 42);
            this.p1Skill.TabIndex = 49;
            this.p1Skill.Tag = "p1";
            this.p1Skill.Text = "技能";
            this.p1Skill.UseVisualStyleBackColor = false;
            this.p1Skill.Visible = false;
            // 
            // p1Skip
            // 
            this.p1Skip.BackColor = System.Drawing.SystemColors.Window;
            this.p1Skip.Location = new System.Drawing.Point(135, 326);
            this.p1Skip.Name = "p1Skip";
            this.p1Skip.Size = new System.Drawing.Size(72, 42);
            this.p1Skip.TabIndex = 50;
            this.p1Skip.Tag = "p1";
            this.p1Skip.Text = "待機";
            this.p1Skip.UseVisualStyleBackColor = false;
            this.p1Skip.Visible = false;
            this.p1Skip.Click += new System.EventHandler(this.p1Skip_Click);
            // 
            // p1Over
            // 
            this.p1Over.BackColor = System.Drawing.SystemColors.Window;
            this.p1Over.Enabled = false;
            this.p1Over.Location = new System.Drawing.Point(69, 378);
            this.p1Over.Name = "p1Over";
            this.p1Over.Size = new System.Drawing.Size(112, 46);
            this.p1Over.TabIndex = 51;
            this.p1Over.Tag = "p1";
            this.p1Over.Text = "結束";
            this.p1Over.UseVisualStyleBackColor = false;
            this.p1Over.Visible = false;
            this.p1Over.Click += new System.EventHandler(this.p1Over_Click);
            // 
            // p2Over
            // 
            this.p2Over.BackColor = System.Drawing.SystemColors.Window;
            this.p2Over.Enabled = false;
            this.p2Over.Location = new System.Drawing.Point(614, 378);
            this.p2Over.Name = "p2Over";
            this.p2Over.Size = new System.Drawing.Size(112, 46);
            this.p2Over.TabIndex = 56;
            this.p2Over.Tag = "p2";
            this.p2Over.Text = "結束";
            this.p2Over.UseVisualStyleBackColor = false;
            this.p2Over.Visible = false;
            this.p2Over.Click += new System.EventHandler(this.p2Over_Click);
            // 
            // p2Skip
            // 
            this.p2Skip.BackColor = System.Drawing.SystemColors.Window;
            this.p2Skip.Enabled = false;
            this.p2Skip.Location = new System.Drawing.Point(680, 326);
            this.p2Skip.Name = "p2Skip";
            this.p2Skip.Size = new System.Drawing.Size(72, 42);
            this.p2Skip.TabIndex = 55;
            this.p2Skip.Tag = "p2";
            this.p2Skip.Text = "待機";
            this.p2Skip.UseVisualStyleBackColor = false;
            this.p2Skip.Visible = false;
            this.p2Skip.Click += new System.EventHandler(this.p2Skip_Click);
            // 
            // p2Skill
            // 
            this.p2Skill.BackColor = System.Drawing.SystemColors.Window;
            this.p2Skill.Enabled = false;
            this.p2Skill.Location = new System.Drawing.Point(589, 326);
            this.p2Skill.Name = "p2Skill";
            this.p2Skill.Size = new System.Drawing.Size(72, 42);
            this.p2Skill.TabIndex = 54;
            this.p2Skill.Tag = "p2";
            this.p2Skill.Text = "技能";
            this.p2Skill.UseVisualStyleBackColor = false;
            this.p2Skill.Visible = false;
            // 
            // p2Move
            // 
            this.p2Move.BackColor = System.Drawing.SystemColors.Window;
            this.p2Move.Enabled = false;
            this.p2Move.Location = new System.Drawing.Point(680, 269);
            this.p2Move.Name = "p2Move";
            this.p2Move.Size = new System.Drawing.Size(72, 42);
            this.p2Move.TabIndex = 53;
            this.p2Move.Tag = "p2";
            this.p2Move.Text = "移動";
            this.p2Move.UseVisualStyleBackColor = false;
            this.p2Move.Visible = false;
            // 
            // p2Atk
            // 
            this.p2Atk.BackColor = System.Drawing.SystemColors.Window;
            this.p2Atk.Enabled = false;
            this.p2Atk.Location = new System.Drawing.Point(589, 269);
            this.p2Atk.Name = "p2Atk";
            this.p2Atk.Size = new System.Drawing.Size(72, 42);
            this.p2Atk.TabIndex = 52;
            this.p2Atk.Tag = "p2";
            this.p2Atk.Text = "攻擊";
            this.p2Atk.UseVisualStyleBackColor = false;
            this.p2Atk.Visible = false;
            // 
            // p1ChooseWiz
            // 
            this.p1ChooseWiz.BackColor = System.Drawing.SystemColors.Window;
            this.p1ChooseWiz.Location = new System.Drawing.Point(77, 202);
            this.p1ChooseWiz.Name = "p1ChooseWiz";
            this.p1ChooseWiz.Size = new System.Drawing.Size(91, 36);
            this.p1ChooseWiz.TabIndex = 58;
            this.p1ChooseWiz.Tag = "Wiz";
            this.p1ChooseWiz.Text = "法師: 1顆";
            this.p1ChooseWiz.UseVisualStyleBackColor = false;
            this.p1ChooseWiz.Visible = false;
            // 
            // p1ChooseRan
            // 
            this.p1ChooseRan.BackColor = System.Drawing.SystemColors.Window;
            this.p1ChooseRan.Location = new System.Drawing.Point(77, 255);
            this.p1ChooseRan.Name = "p1ChooseRan";
            this.p1ChooseRan.Size = new System.Drawing.Size(91, 36);
            this.p1ChooseRan.TabIndex = 59;
            this.p1ChooseRan.Tag = "Ran";
            this.p1ChooseRan.Text = "遊俠: 1顆";
            this.p1ChooseRan.UseVisualStyleBackColor = false;
            this.p1ChooseRan.Visible = false;
            // 
            // p2ChooseRan
            // 
            this.p2ChooseRan.BackColor = System.Drawing.SystemColors.Window;
            this.p2ChooseRan.Enabled = false;
            this.p2ChooseRan.Location = new System.Drawing.Point(625, 255);
            this.p2ChooseRan.Name = "p2ChooseRan";
            this.p2ChooseRan.Size = new System.Drawing.Size(91, 36);
            this.p2ChooseRan.TabIndex = 62;
            this.p2ChooseRan.Tag = "Ran";
            this.p2ChooseRan.Text = "遊俠: 1顆";
            this.p2ChooseRan.UseVisualStyleBackColor = false;
            this.p2ChooseRan.Visible = false;
            // 
            // p2ChooseWiz
            // 
            this.p2ChooseWiz.BackColor = System.Drawing.SystemColors.Window;
            this.p2ChooseWiz.Enabled = false;
            this.p2ChooseWiz.Location = new System.Drawing.Point(625, 202);
            this.p2ChooseWiz.Name = "p2ChooseWiz";
            this.p2ChooseWiz.Size = new System.Drawing.Size(91, 36);
            this.p2ChooseWiz.TabIndex = 61;
            this.p2ChooseWiz.Tag = "Wiz";
            this.p2ChooseWiz.Text = "法師: 1顆";
            this.p2ChooseWiz.UseVisualStyleBackColor = false;
            this.p2ChooseWiz.Visible = false;
            // 
            // p2ChooseWar
            // 
            this.p2ChooseWar.BackColor = System.Drawing.SystemColors.Window;
            this.p2ChooseWar.Enabled = false;
            this.p2ChooseWar.Location = new System.Drawing.Point(625, 152);
            this.p2ChooseWar.Name = "p2ChooseWar";
            this.p2ChooseWar.Size = new System.Drawing.Size(91, 36);
            this.p2ChooseWar.TabIndex = 60;
            this.p2ChooseWar.Tag = "War";
            this.p2ChooseWar.Text = "戰士: 1顆";
            this.p2ChooseWar.UseVisualStyleBackColor = false;
            this.p2ChooseWar.Visible = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Window;
            this.button4.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Location = new System.Drawing.Point(400, 100);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 50);
            this.button4.TabIndex = 63;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Window;
            this.button5.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.Location = new System.Drawing.Point(450, 100);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 64;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Window;
            this.button6.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button6.Location = new System.Drawing.Point(500, 100);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 65;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Visible = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Window;
            this.button7.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button7.Location = new System.Drawing.Point(250, 150);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 50);
            this.button7.TabIndex = 66;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Visible = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Window;
            this.button8.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button8.Location = new System.Drawing.Point(300, 150);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 50);
            this.button8.TabIndex = 67;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Visible = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.Window;
            this.button9.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button9.Location = new System.Drawing.Point(350, 150);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 50);
            this.button9.TabIndex = 68;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Visible = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Window;
            this.button10.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button10.Location = new System.Drawing.Point(400, 150);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(50, 50);
            this.button10.TabIndex = 69;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Visible = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.Window;
            this.button11.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button11.Location = new System.Drawing.Point(450, 150);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(50, 50);
            this.button11.TabIndex = 70;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Visible = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.Window;
            this.button12.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button12.Location = new System.Drawing.Point(500, 150);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(50, 50);
            this.button12.TabIndex = 71;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Visible = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.Window;
            this.button13.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button13.Location = new System.Drawing.Point(250, 200);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 50);
            this.button13.TabIndex = 72;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Visible = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.Window;
            this.button14.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button14.Location = new System.Drawing.Point(300, 200);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(50, 50);
            this.button14.TabIndex = 73;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Visible = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.Window;
            this.button15.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button15.Location = new System.Drawing.Point(350, 200);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(50, 50);
            this.button15.TabIndex = 74;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Visible = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.Window;
            this.button16.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button16.Location = new System.Drawing.Point(400, 200);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(50, 50);
            this.button16.TabIndex = 75;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Visible = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.Window;
            this.button17.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button17.Location = new System.Drawing.Point(450, 200);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(50, 50);
            this.button17.TabIndex = 76;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Visible = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.Window;
            this.button18.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button18.Location = new System.Drawing.Point(500, 200);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(50, 50);
            this.button18.TabIndex = 77;
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Visible = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.Window;
            this.button19.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button19.Location = new System.Drawing.Point(250, 250);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(50, 50);
            this.button19.TabIndex = 78;
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Visible = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.Window;
            this.button20.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button20.Location = new System.Drawing.Point(300, 250);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(50, 50);
            this.button20.TabIndex = 79;
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Visible = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.Window;
            this.button21.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button21.Location = new System.Drawing.Point(350, 250);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(50, 50);
            this.button21.TabIndex = 80;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Visible = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.Window;
            this.button22.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button22.Location = new System.Drawing.Point(400, 250);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(50, 50);
            this.button22.TabIndex = 81;
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Visible = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.Window;
            this.button23.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button23.Location = new System.Drawing.Point(450, 250);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(50, 50);
            this.button23.TabIndex = 82;
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Visible = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.Window;
            this.button24.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button24.Location = new System.Drawing.Point(500, 250);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(50, 50);
            this.button24.TabIndex = 83;
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Visible = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.Window;
            this.button25.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button25.Location = new System.Drawing.Point(250, 300);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(50, 50);
            this.button25.TabIndex = 84;
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Visible = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.Window;
            this.button26.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button26.Location = new System.Drawing.Point(300, 300);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(50, 50);
            this.button26.TabIndex = 85;
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Visible = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.Window;
            this.button27.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button27.Location = new System.Drawing.Point(350, 300);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(50, 50);
            this.button27.TabIndex = 86;
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Visible = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.SystemColors.Window;
            this.button28.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button28.Location = new System.Drawing.Point(400, 300);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(50, 50);
            this.button28.TabIndex = 87;
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Visible = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.Window;
            this.button29.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button29.Location = new System.Drawing.Point(450, 300);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(50, 50);
            this.button29.TabIndex = 88;
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Visible = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.Window;
            this.button30.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button30.Location = new System.Drawing.Point(500, 300);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(50, 50);
            this.button30.TabIndex = 89;
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Visible = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.Window;
            this.button31.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button31.Location = new System.Drawing.Point(250, 350);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(50, 50);
            this.button31.TabIndex = 90;
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Visible = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.Window;
            this.button32.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button32.Location = new System.Drawing.Point(300, 350);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(50, 50);
            this.button32.TabIndex = 91;
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Visible = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.Window;
            this.button33.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button33.Location = new System.Drawing.Point(350, 350);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(50, 50);
            this.button33.TabIndex = 92;
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Visible = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.SystemColors.Window;
            this.button34.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button34.Location = new System.Drawing.Point(400, 350);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(50, 50);
            this.button34.TabIndex = 93;
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Visible = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.Window;
            this.button35.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button35.Location = new System.Drawing.Point(450, 350);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(50, 50);
            this.button35.TabIndex = 94;
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Visible = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.Window;
            this.button36.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button36.Location = new System.Drawing.Point(500, 350);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(50, 50);
            this.button36.TabIndex = 95;
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Visible = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.SystemColors.Window;
            this.button37.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button37.Location = new System.Drawing.Point(250, 400);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(50, 50);
            this.button37.TabIndex = 96;
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Visible = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.Window;
            this.button38.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button38.Location = new System.Drawing.Point(300, 400);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(50, 50);
            this.button38.TabIndex = 97;
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Visible = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.Window;
            this.button39.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button39.Location = new System.Drawing.Point(350, 400);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(50, 50);
            this.button39.TabIndex = 98;
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Visible = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.SystemColors.Window;
            this.button40.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button40.Location = new System.Drawing.Point(400, 400);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(50, 50);
            this.button40.TabIndex = 99;
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Visible = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.SystemColors.Window;
            this.button41.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button41.Location = new System.Drawing.Point(450, 400);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(50, 50);
            this.button41.TabIndex = 100;
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Visible = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.Window;
            this.button42.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button42.Location = new System.Drawing.Point(500, 400);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(50, 50);
            this.button42.TabIndex = 101;
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Visible = false;
            // 
            // p1ChooseWar
            // 
            this.p1ChooseWar.BackColor = System.Drawing.SystemColors.Window;
            this.p1ChooseWar.Location = new System.Drawing.Point(77, 152);
            this.p1ChooseWar.Name = "p1ChooseWar";
            this.p1ChooseWar.Size = new System.Drawing.Size(91, 36);
            this.p1ChooseWar.TabIndex = 57;
            this.p1ChooseWar.Tag = "War";
            this.p1ChooseWar.Text = "戰士: 1顆";
            this.p1ChooseWar.UseVisualStyleBackColor = false;
            this.p1ChooseWar.Visible = false;
            this.p1ChooseWar.Click += new System.EventHandler(this.p1ChooseWar_Click);
            // 
            // p1CharLabel
            // 
            this.p1CharLabel.AutoSize = true;
            this.p1CharLabel.Font = new System.Drawing.Font("新細明體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.p1CharLabel.Location = new System.Drawing.Point(87, 105);
            this.p1CharLabel.Name = "p1CharLabel";
            this.p1CharLabel.Size = new System.Drawing.Size(0, 33);
            this.p1CharLabel.TabIndex = 102;
            this.p1CharLabel.Visible = false;
            // 
            // p2CharLabel
            // 
            this.p2CharLabel.AutoSize = true;
            this.p2CharLabel.Font = new System.Drawing.Font("新細明體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.p2CharLabel.Location = new System.Drawing.Point(631, 104);
            this.p2CharLabel.Name = "p2CharLabel";
            this.p2CharLabel.Size = new System.Drawing.Size(0, 33);
            this.p2CharLabel.TabIndex = 103;
            this.p2CharLabel.Visible = false;
            // 
            // p1InfoLabel
            // 
            this.p1InfoLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.p1InfoLabel.Location = new System.Drawing.Point(74, 150);
            this.p1InfoLabel.Name = "p1InfoLabel";
            this.p1InfoLabel.Size = new System.Drawing.Size(148, 116);
            this.p1InfoLabel.TabIndex = 104;
            this.p1InfoLabel.Text = "Hp:90";
            this.p1InfoLabel.Visible = false;
            // 
            // p2InfoLabel
            // 
            this.p2InfoLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.p2InfoLabel.Location = new System.Drawing.Point(622, 150);
            this.p2InfoLabel.Name = "p2InfoLabel";
            this.p2InfoLabel.Size = new System.Drawing.Size(141, 116);
            this.p2InfoLabel.TabIndex = 105;
            this.p2InfoLabel.Text = "Hp:90";
            this.p2InfoLabel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 483);
            this.Controls.Add(this.p2CharLabel);
            this.Controls.Add(this.p1CharLabel);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.p2ChooseRan);
            this.Controls.Add(this.p2ChooseWiz);
            this.Controls.Add(this.p2ChooseWar);
            this.Controls.Add(this.p1ChooseRan);
            this.Controls.Add(this.p1ChooseWiz);
            this.Controls.Add(this.p1ChooseWar);
            this.Controls.Add(this.p2Over);
            this.Controls.Add(this.p2Skip);
            this.Controls.Add(this.p2Skill);
            this.Controls.Add(this.p2Move);
            this.Controls.Add(this.p2Atk);
            this.Controls.Add(this.p1Over);
            this.Controls.Add(this.p1Skip);
            this.Controls.Add(this.p1Skill);
            this.Controls.Add(this.p1Move);
            this.Controls.Add(this.p1Atk);
            this.Controls.Add(this.p2Label);
            this.Controls.Add(this.p1Label);
            this.Controls.Add(this.turnLabel);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.p2InfoLabel);
            this.Controls.Add(this.p1InfoLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label turnLabel;
        private System.Windows.Forms.Label p1Label;
        private System.Windows.Forms.Label p2Label;
        private System.Windows.Forms.Button p1Atk;
        private System.Windows.Forms.Button p1Move;
        private System.Windows.Forms.Button p1Skill;
        private System.Windows.Forms.Button p1Skip;
        private System.Windows.Forms.Button p1Over;
        private System.Windows.Forms.Button p2Over;
        private System.Windows.Forms.Button p2Skip;
        private System.Windows.Forms.Button p2Skill;
        private System.Windows.Forms.Button p2Move;
        private System.Windows.Forms.Button p2Atk;
        private System.Windows.Forms.Button p1ChooseWiz;
        private System.Windows.Forms.Button p1ChooseRan;
        private System.Windows.Forms.Button p2ChooseRan;
        private System.Windows.Forms.Button p2ChooseWiz;
        private System.Windows.Forms.Button p2ChooseWar;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button p1ChooseWar;
        private System.Windows.Forms.Label p1CharLabel;
        private System.Windows.Forms.Label p2CharLabel;
        private System.Windows.Forms.Label p1InfoLabel;
        private System.Windows.Forms.Label p2InfoLabel;
    }
}

