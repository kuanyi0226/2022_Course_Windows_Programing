﻿namespace c34104032_practice_4_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.nameLabel = new System.Windows.Forms.Label();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.restartButton = new System.Windows.Forms.Button();
            this.pic10 = new System.Windows.Forms.Button();
            this.pic20 = new System.Windows.Forms.Button();
            this.pic30 = new System.Windows.Forms.Button();
            this.pic00 = new System.Windows.Forms.Button();
            this.pic21 = new System.Windows.Forms.Button();
            this.pic31 = new System.Windows.Forms.Button();
            this.pic32 = new System.Windows.Forms.Button();
            this.pic22 = new System.Windows.Forms.Button();
            this.pic02 = new System.Windows.Forms.Button();
            this.pic01 = new System.Windows.Forms.Button();
            this.pic11 = new System.Windows.Forms.Button();
            this.pic12 = new System.Windows.Forms.Button();
            this.pic23 = new System.Windows.Forms.Button();
            this.pic33 = new System.Windows.Forms.Button();
            this.pic13 = new System.Windows.Forms.Button();
            this.pic03 = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.contiButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.recordLabel = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 43);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(912, 562);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.nameBox);
            this.tabPage1.Controls.Add(this.nameLabel);
            this.tabPage1.Controls.Add(this.scoreLabel);
            this.tabPage1.Controls.Add(this.restartButton);
            this.tabPage1.Controls.Add(this.pic10);
            this.tabPage1.Controls.Add(this.pic20);
            this.tabPage1.Controls.Add(this.pic30);
            this.tabPage1.Controls.Add(this.pic00);
            this.tabPage1.Controls.Add(this.pic21);
            this.tabPage1.Controls.Add(this.pic31);
            this.tabPage1.Controls.Add(this.pic32);
            this.tabPage1.Controls.Add(this.pic22);
            this.tabPage1.Controls.Add(this.pic02);
            this.tabPage1.Controls.Add(this.pic01);
            this.tabPage1.Controls.Add(this.pic11);
            this.tabPage1.Controls.Add(this.pic12);
            this.tabPage1.Controls.Add(this.pic23);
            this.tabPage1.Controls.Add(this.pic33);
            this.tabPage1.Controls.Add(this.pic13);
            this.tabPage1.Controls.Add(this.pic03);
            this.tabPage1.Controls.Add(this.quitButton);
            this.tabPage1.Controls.Add(this.contiButton);
            this.tabPage1.Controls.Add(this.startButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(904, 533);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "遊玩區";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.nameLabel.Location = new System.Drawing.Point(195, 7);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(64, 24);
            this.nameLabel.TabIndex = 57;
            this.nameLabel.Text = "名稱:";
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Font = new System.Drawing.Font("新細明體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.scoreLabel.Location = new System.Drawing.Point(3, 3);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(121, 28);
            this.scoreLabel.TabIndex = 56;
            this.scoreLabel.Text = "分數: 100";
            // 
            // restartButton
            // 
            this.restartButton.Location = new System.Drawing.Point(759, 207);
            this.restartButton.Margin = new System.Windows.Forms.Padding(4);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(100, 50);
            this.restartButton.TabIndex = 55;
            this.restartButton.Text = "重新開始";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // pic10
            // 
            this.pic10.BackColor = System.Drawing.SystemColors.Window;
            this.pic10.Location = new System.Drawing.Point(55, 165);
            this.pic10.Name = "pic10";
            this.pic10.Size = new System.Drawing.Size(95, 115);
            this.pic10.TabIndex = 54;
            this.pic10.UseVisualStyleBackColor = false;
            this.pic10.Visible = false;
            this.pic10.Click += new System.EventHandler(this.pic10_Click);
            // 
            // pic20
            // 
            this.pic20.BackColor = System.Drawing.SystemColors.Window;
            this.pic20.Location = new System.Drawing.Point(55, 288);
            this.pic20.Name = "pic20";
            this.pic20.Size = new System.Drawing.Size(95, 115);
            this.pic20.TabIndex = 53;
            this.pic20.UseVisualStyleBackColor = false;
            this.pic20.Visible = false;
            this.pic20.Click += new System.EventHandler(this.pic20_Click);
            // 
            // pic30
            // 
            this.pic30.BackColor = System.Drawing.SystemColors.Window;
            this.pic30.Location = new System.Drawing.Point(55, 414);
            this.pic30.Name = "pic30";
            this.pic30.Size = new System.Drawing.Size(95, 115);
            this.pic30.TabIndex = 52;
            this.pic30.UseVisualStyleBackColor = false;
            this.pic30.Visible = false;
            this.pic30.Click += new System.EventHandler(this.pic30_Click);
            // 
            // pic00
            // 
            this.pic00.BackColor = System.Drawing.SystemColors.Window;
            this.pic00.Location = new System.Drawing.Point(55, 43);
            this.pic00.Name = "pic00";
            this.pic00.Size = new System.Drawing.Size(95, 115);
            this.pic00.TabIndex = 51;
            this.pic00.UseVisualStyleBackColor = false;
            this.pic00.Visible = false;
            this.pic00.Click += new System.EventHandler(this.pic00_Click);
            // 
            // pic21
            // 
            this.pic21.BackColor = System.Drawing.SystemColors.Window;
            this.pic21.Location = new System.Drawing.Point(199, 288);
            this.pic21.Name = "pic21";
            this.pic21.Size = new System.Drawing.Size(95, 115);
            this.pic21.TabIndex = 50;
            this.pic21.UseVisualStyleBackColor = false;
            this.pic21.Visible = false;
            this.pic21.Click += new System.EventHandler(this.pic21_Click);
            // 
            // pic31
            // 
            this.pic31.BackColor = System.Drawing.SystemColors.Window;
            this.pic31.Location = new System.Drawing.Point(199, 414);
            this.pic31.Name = "pic31";
            this.pic31.Size = new System.Drawing.Size(95, 115);
            this.pic31.TabIndex = 49;
            this.pic31.UseVisualStyleBackColor = false;
            this.pic31.Visible = false;
            this.pic31.Click += new System.EventHandler(this.pic31_Click);
            // 
            // pic32
            // 
            this.pic32.BackColor = System.Drawing.SystemColors.Window;
            this.pic32.Location = new System.Drawing.Point(344, 414);
            this.pic32.Name = "pic32";
            this.pic32.Size = new System.Drawing.Size(95, 115);
            this.pic32.TabIndex = 48;
            this.pic32.UseVisualStyleBackColor = false;
            this.pic32.Visible = false;
            this.pic32.Click += new System.EventHandler(this.pic32_Click);
            // 
            // pic22
            // 
            this.pic22.BackColor = System.Drawing.SystemColors.Window;
            this.pic22.Location = new System.Drawing.Point(344, 288);
            this.pic22.Name = "pic22";
            this.pic22.Size = new System.Drawing.Size(95, 115);
            this.pic22.TabIndex = 47;
            this.pic22.UseVisualStyleBackColor = false;
            this.pic22.Visible = false;
            this.pic22.Click += new System.EventHandler(this.pic22_Click);
            // 
            // pic02
            // 
            this.pic02.BackColor = System.Drawing.SystemColors.Window;
            this.pic02.Location = new System.Drawing.Point(344, 43);
            this.pic02.Name = "pic02";
            this.pic02.Size = new System.Drawing.Size(95, 115);
            this.pic02.TabIndex = 46;
            this.pic02.UseVisualStyleBackColor = false;
            this.pic02.Visible = false;
            this.pic02.Click += new System.EventHandler(this.pic02_Click);
            // 
            // pic01
            // 
            this.pic01.BackColor = System.Drawing.SystemColors.Window;
            this.pic01.Location = new System.Drawing.Point(199, 43);
            this.pic01.Name = "pic01";
            this.pic01.Size = new System.Drawing.Size(95, 115);
            this.pic01.TabIndex = 45;
            this.pic01.UseVisualStyleBackColor = false;
            this.pic01.Visible = false;
            this.pic01.Click += new System.EventHandler(this.pic01_Click);
            // 
            // pic11
            // 
            this.pic11.BackColor = System.Drawing.SystemColors.Window;
            this.pic11.Location = new System.Drawing.Point(199, 165);
            this.pic11.Name = "pic11";
            this.pic11.Size = new System.Drawing.Size(95, 115);
            this.pic11.TabIndex = 44;
            this.pic11.UseVisualStyleBackColor = false;
            this.pic11.Visible = false;
            this.pic11.Click += new System.EventHandler(this.pic11_Click);
            // 
            // pic12
            // 
            this.pic12.BackColor = System.Drawing.SystemColors.Window;
            this.pic12.Location = new System.Drawing.Point(344, 165);
            this.pic12.Name = "pic12";
            this.pic12.Size = new System.Drawing.Size(95, 115);
            this.pic12.TabIndex = 43;
            this.pic12.UseVisualStyleBackColor = false;
            this.pic12.Visible = false;
            this.pic12.Click += new System.EventHandler(this.pic12_Click);
            // 
            // pic23
            // 
            this.pic23.BackColor = System.Drawing.SystemColors.Window;
            this.pic23.Location = new System.Drawing.Point(488, 286);
            this.pic23.Name = "pic23";
            this.pic23.Size = new System.Drawing.Size(95, 115);
            this.pic23.TabIndex = 42;
            this.pic23.UseVisualStyleBackColor = false;
            this.pic23.Visible = false;
            this.pic23.Click += new System.EventHandler(this.pic23_Click);
            // 
            // pic33
            // 
            this.pic33.BackColor = System.Drawing.SystemColors.Window;
            this.pic33.Location = new System.Drawing.Point(488, 414);
            this.pic33.Name = "pic33";
            this.pic33.Size = new System.Drawing.Size(95, 115);
            this.pic33.TabIndex = 41;
            this.pic33.UseVisualStyleBackColor = false;
            this.pic33.Visible = false;
            this.pic33.Click += new System.EventHandler(this.pic33_Click);
            // 
            // pic13
            // 
            this.pic13.BackColor = System.Drawing.SystemColors.Window;
            this.pic13.Location = new System.Drawing.Point(488, 165);
            this.pic13.Name = "pic13";
            this.pic13.Size = new System.Drawing.Size(95, 115);
            this.pic13.TabIndex = 40;
            this.pic13.UseVisualStyleBackColor = false;
            this.pic13.Visible = false;
            this.pic13.Click += new System.EventHandler(this.pic13_Click);
            // 
            // pic03
            // 
            this.pic03.BackColor = System.Drawing.SystemColors.Window;
            this.pic03.Location = new System.Drawing.Point(488, 43);
            this.pic03.Name = "pic03";
            this.pic03.Size = new System.Drawing.Size(95, 115);
            this.pic03.TabIndex = 39;
            this.pic03.UseVisualStyleBackColor = false;
            this.pic03.Visible = false;
            this.pic03.Click += new System.EventHandler(this.pic03_Click);
            // 
            // quitButton
            // 
            this.quitButton.Location = new System.Drawing.Point(759, 400);
            this.quitButton.Margin = new System.Windows.Forms.Padding(4);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(100, 50);
            this.quitButton.TabIndex = 38;
            this.quitButton.Text = "離開遊戲";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // contiButton
            // 
            this.contiButton.Enabled = false;
            this.contiButton.Location = new System.Drawing.Point(759, 117);
            this.contiButton.Margin = new System.Windows.Forms.Padding(4);
            this.contiButton.Name = "contiButton";
            this.contiButton.Size = new System.Drawing.Size(100, 50);
            this.contiButton.TabIndex = 37;
            this.contiButton.Text = "繼續";
            this.contiButton.UseVisualStyleBackColor = true;
            this.contiButton.Click += new System.EventHandler(this.contiButton_Click);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(759, 29);
            this.startButton.Margin = new System.Windows.Forms.Padding(4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(100, 50);
            this.startButton.TabIndex = 36;
            this.startButton.Text = "開始遊戲";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.recordLabel);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(904, 533);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "歷史紀錄區";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "翻牌小遊戲";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(265, 7);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(318, 25);
            this.nameBox.TabIndex = 58;
            // 
            // recordLabel
            // 
            this.recordLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.recordLabel.Location = new System.Drawing.Point(26, 22);
            this.recordLabel.Name = "recordLabel";
            this.recordLabel.Size = new System.Drawing.Size(846, 482);
            this.recordLabel.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(936, 607);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.Button pic10;
        private System.Windows.Forms.Button pic20;
        private System.Windows.Forms.Button pic30;
        private System.Windows.Forms.Button pic00;
        private System.Windows.Forms.Button pic21;
        private System.Windows.Forms.Button pic31;
        private System.Windows.Forms.Button pic32;
        private System.Windows.Forms.Button pic22;
        private System.Windows.Forms.Button pic02;
        private System.Windows.Forms.Button pic01;
        private System.Windows.Forms.Button pic11;
        private System.Windows.Forms.Button pic12;
        private System.Windows.Forms.Button pic23;
        private System.Windows.Forms.Button pic33;
        private System.Windows.Forms.Button pic13;
        private System.Windows.Forms.Button pic03;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Button contiButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label recordLabel;
    }
}

