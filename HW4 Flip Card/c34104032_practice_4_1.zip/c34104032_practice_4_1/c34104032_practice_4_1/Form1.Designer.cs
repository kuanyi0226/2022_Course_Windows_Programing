﻿namespace c34104032_practice_4_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.startButton = new System.Windows.Forms.Button();
            this.contiButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pic03 = new System.Windows.Forms.Button();
            this.pic13 = new System.Windows.Forms.Button();
            this.pic33 = new System.Windows.Forms.Button();
            this.pic23 = new System.Windows.Forms.Button();
            this.pic12 = new System.Windows.Forms.Button();
            this.pic11 = new System.Windows.Forms.Button();
            this.pic01 = new System.Windows.Forms.Button();
            this.pic02 = new System.Windows.Forms.Button();
            this.pic22 = new System.Windows.Forms.Button();
            this.pic32 = new System.Windows.Forms.Button();
            this.pic31 = new System.Windows.Forms.Button();
            this.pic21 = new System.Windows.Forms.Button();
            this.pic00 = new System.Windows.Forms.Button();
            this.pic30 = new System.Windows.Forms.Button();
            this.pic20 = new System.Windows.Forms.Button();
            this.pic10 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(704, 138);
            this.startButton.Margin = new System.Windows.Forms.Padding(4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(100, 50);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "開始遊戲";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // contiButton
            // 
            this.contiButton.Enabled = false;
            this.contiButton.Location = new System.Drawing.Point(704, 241);
            this.contiButton.Margin = new System.Windows.Forms.Padding(4);
            this.contiButton.Name = "contiButton";
            this.contiButton.Size = new System.Drawing.Size(100, 50);
            this.contiButton.TabIndex = 1;
            this.contiButton.Text = "繼續";
            this.contiButton.UseVisualStyleBackColor = true;
            this.contiButton.Click += new System.EventHandler(this.contiButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.Location = new System.Drawing.Point(704, 339);
            this.quitButton.Margin = new System.Windows.Forms.Padding(4);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(100, 50);
            this.quitButton.TabIndex = 2;
            this.quitButton.Text = "離開遊戲";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(25, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "翻牌小遊戲";
            // 
            // pic03
            // 
            this.pic03.BackColor = System.Drawing.SystemColors.Window;
            this.pic03.Location = new System.Drawing.Point(464, 54);
            this.pic03.Name = "pic03";
            this.pic03.Size = new System.Drawing.Size(95, 115);
            this.pic03.TabIndex = 20;
            this.pic03.UseVisualStyleBackColor = false;
            this.pic03.Visible = false;
            this.pic03.Click += new System.EventHandler(this.pic03_Click);
            // 
            // pic13
            // 
            this.pic13.BackColor = System.Drawing.SystemColors.Window;
            this.pic13.Location = new System.Drawing.Point(464, 176);
            this.pic13.Name = "pic13";
            this.pic13.Size = new System.Drawing.Size(95, 115);
            this.pic13.TabIndex = 21;
            this.pic13.UseVisualStyleBackColor = false;
            this.pic13.Visible = false;
            this.pic13.Click += new System.EventHandler(this.pic13_Click);
            // 
            // pic33
            // 
            this.pic33.BackColor = System.Drawing.SystemColors.Window;
            this.pic33.Location = new System.Drawing.Point(464, 425);
            this.pic33.Name = "pic33";
            this.pic33.Size = new System.Drawing.Size(95, 115);
            this.pic33.TabIndex = 22;
            this.pic33.UseVisualStyleBackColor = false;
            this.pic33.Visible = false;
            this.pic33.Click += new System.EventHandler(this.pic33_Click);
            // 
            // pic23
            // 
            this.pic23.BackColor = System.Drawing.SystemColors.Window;
            this.pic23.Location = new System.Drawing.Point(464, 297);
            this.pic23.Name = "pic23";
            this.pic23.Size = new System.Drawing.Size(95, 115);
            this.pic23.TabIndex = 23;
            this.pic23.UseVisualStyleBackColor = false;
            this.pic23.Visible = false;
            this.pic23.Click += new System.EventHandler(this.pic23_Click);
            // 
            // pic12
            // 
            this.pic12.BackColor = System.Drawing.SystemColors.Window;
            this.pic12.Location = new System.Drawing.Point(320, 176);
            this.pic12.Name = "pic12";
            this.pic12.Size = new System.Drawing.Size(95, 115);
            this.pic12.TabIndex = 24;
            this.pic12.UseVisualStyleBackColor = false;
            this.pic12.Visible = false;
            this.pic12.Click += new System.EventHandler(this.pic12_Click);
            // 
            // pic11
            // 
            this.pic11.BackColor = System.Drawing.SystemColors.Window;
            this.pic11.Location = new System.Drawing.Point(175, 176);
            this.pic11.Name = "pic11";
            this.pic11.Size = new System.Drawing.Size(95, 115);
            this.pic11.TabIndex = 25;
            this.pic11.UseVisualStyleBackColor = false;
            this.pic11.Visible = false;
            this.pic11.Click += new System.EventHandler(this.pic11_Click);
            // 
            // pic01
            // 
            this.pic01.BackColor = System.Drawing.SystemColors.Window;
            this.pic01.Location = new System.Drawing.Point(175, 54);
            this.pic01.Name = "pic01";
            this.pic01.Size = new System.Drawing.Size(95, 115);
            this.pic01.TabIndex = 26;
            this.pic01.UseVisualStyleBackColor = false;
            this.pic01.Visible = false;
            this.pic01.Click += new System.EventHandler(this.pic01_Click);
            // 
            // pic02
            // 
            this.pic02.BackColor = System.Drawing.SystemColors.Window;
            this.pic02.Location = new System.Drawing.Point(320, 54);
            this.pic02.Name = "pic02";
            this.pic02.Size = new System.Drawing.Size(95, 115);
            this.pic02.TabIndex = 27;
            this.pic02.UseVisualStyleBackColor = false;
            this.pic02.Visible = false;
            this.pic02.Click += new System.EventHandler(this.pic02_Click);
            // 
            // pic22
            // 
            this.pic22.BackColor = System.Drawing.SystemColors.Window;
            this.pic22.Location = new System.Drawing.Point(320, 299);
            this.pic22.Name = "pic22";
            this.pic22.Size = new System.Drawing.Size(95, 115);
            this.pic22.TabIndex = 28;
            this.pic22.UseVisualStyleBackColor = false;
            this.pic22.Visible = false;
            this.pic22.Click += new System.EventHandler(this.pic22_Click);
            // 
            // pic32
            // 
            this.pic32.BackColor = System.Drawing.SystemColors.Window;
            this.pic32.Location = new System.Drawing.Point(320, 425);
            this.pic32.Name = "pic32";
            this.pic32.Size = new System.Drawing.Size(95, 115);
            this.pic32.TabIndex = 29;
            this.pic32.UseVisualStyleBackColor = false;
            this.pic32.Visible = false;
            this.pic32.Click += new System.EventHandler(this.pic32_Click);
            // 
            // pic31
            // 
            this.pic31.BackColor = System.Drawing.SystemColors.Window;
            this.pic31.Location = new System.Drawing.Point(175, 425);
            this.pic31.Name = "pic31";
            this.pic31.Size = new System.Drawing.Size(95, 115);
            this.pic31.TabIndex = 30;
            this.pic31.UseVisualStyleBackColor = false;
            this.pic31.Visible = false;
            this.pic31.Click += new System.EventHandler(this.pic31_Click);
            // 
            // pic21
            // 
            this.pic21.BackColor = System.Drawing.SystemColors.Window;
            this.pic21.Location = new System.Drawing.Point(175, 299);
            this.pic21.Name = "pic21";
            this.pic21.Size = new System.Drawing.Size(95, 115);
            this.pic21.TabIndex = 31;
            this.pic21.UseVisualStyleBackColor = false;
            this.pic21.Visible = false;
            this.pic21.Click += new System.EventHandler(this.pic21_Click);
            // 
            // pic00
            // 
            this.pic00.BackColor = System.Drawing.SystemColors.Window;
            this.pic00.Location = new System.Drawing.Point(31, 54);
            this.pic00.Name = "pic00";
            this.pic00.Size = new System.Drawing.Size(95, 115);
            this.pic00.TabIndex = 32;
            this.pic00.UseVisualStyleBackColor = false;
            this.pic00.Visible = false;
            this.pic00.Click += new System.EventHandler(this.pic00_Click);
            // 
            // pic30
            // 
            this.pic30.BackColor = System.Drawing.SystemColors.Window;
            this.pic30.Location = new System.Drawing.Point(31, 425);
            this.pic30.Name = "pic30";
            this.pic30.Size = new System.Drawing.Size(95, 115);
            this.pic30.TabIndex = 33;
            this.pic30.UseVisualStyleBackColor = false;
            this.pic30.Visible = false;
            this.pic30.Click += new System.EventHandler(this.pic30_Click);
            // 
            // pic20
            // 
            this.pic20.BackColor = System.Drawing.SystemColors.Window;
            this.pic20.Location = new System.Drawing.Point(31, 299);
            this.pic20.Name = "pic20";
            this.pic20.Size = new System.Drawing.Size(95, 115);
            this.pic20.TabIndex = 34;
            this.pic20.UseVisualStyleBackColor = false;
            this.pic20.Visible = false;
            this.pic20.Click += new System.EventHandler(this.pic20_Click);
            // 
            // pic10
            // 
            this.pic10.BackColor = System.Drawing.SystemColors.Window;
            this.pic10.Location = new System.Drawing.Point(31, 176);
            this.pic10.Name = "pic10";
            this.pic10.Size = new System.Drawing.Size(95, 115);
            this.pic10.TabIndex = 35;
            this.pic10.UseVisualStyleBackColor = false;
            this.pic10.Visible = false;
            this.pic10.Click += new System.EventHandler(this.pic10_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 552);
            this.Controls.Add(this.pic10);
            this.Controls.Add(this.pic20);
            this.Controls.Add(this.pic30);
            this.Controls.Add(this.pic00);
            this.Controls.Add(this.pic21);
            this.Controls.Add(this.pic31);
            this.Controls.Add(this.pic32);
            this.Controls.Add(this.pic22);
            this.Controls.Add(this.pic02);
            this.Controls.Add(this.pic01);
            this.Controls.Add(this.pic11);
            this.Controls.Add(this.pic12);
            this.Controls.Add(this.pic23);
            this.Controls.Add(this.pic33);
            this.Controls.Add(this.pic13);
            this.Controls.Add(this.pic03);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.contiButton);
            this.Controls.Add(this.startButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button contiButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button pic03;
        private System.Windows.Forms.Button pic13;
        private System.Windows.Forms.Button pic33;
        private System.Windows.Forms.Button pic23;
        private System.Windows.Forms.Button pic12;
        private System.Windows.Forms.Button pic11;
        private System.Windows.Forms.Button pic01;
        private System.Windows.Forms.Button pic02;
        private System.Windows.Forms.Button pic22;
        private System.Windows.Forms.Button pic32;
        private System.Windows.Forms.Button pic31;
        private System.Windows.Forms.Button pic21;
        private System.Windows.Forms.Button pic00;
        private System.Windows.Forms.Button pic30;
        private System.Windows.Forms.Button pic20;
        private System.Windows.Forms.Button pic10;
    }
}

